#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <memory.h>
#include <unistd.h>
#include <pthread.h>

// Global varibales
struct user_t* users[250];
int iter = 0;

#define DO_SYS(syscall) do {		\
    if( (syscall) == -1 ) {		\
        perror( #syscall );		\
        exit(EXIT_FAILURE);		\
    }						\
} while( 0 )

struct addrinfo*
alloc_tcp_addr(const char *host, uint16_t port, int flags)
{
    int err;   struct addrinfo hint, *a;   char ps[16];

    snprintf(ps, sizeof(ps), "%hu", port); // why string?
    memset(&hint, 0, sizeof(hint));
    hint.ai_flags    = flags;
    hint.ai_family   = AF_UNSPEC;
    hint.ai_socktype = SOCK_STREAM;
    hint.ai_protocol = IPPROTO_TCP;

    if( (err = getaddrinfo(host, ps, &hint, &a)) != 0 ) {
        fprintf(stderr,"%s\n", gai_strerror(err));
        exit(EXIT_FAILURE);
    }

    return a; // should later be freed with freeaddrinfo()
}

int tcp_establish(int port) {
    int srvfd;
    struct addrinfo *a =
	    alloc_tcp_addr(NULL/*host*/, port, AI_PASSIVE);
    DO_SYS( srvfd = socket( a->ai_family,
				 a->ai_socktype,
				 a->ai_protocol ) 	);
    DO_SYS( bind( srvfd,
				 a->ai_addr,
				 a->ai_addrlen  ) 	);
    DO_SYS( listen( srvfd,
				 5/*backlog*/   ) 	);
    freeaddrinfo( a );
    return srvfd;
}

typedef struct tpool_t {
    pthread_mutex_t  work_mutex;
    pthread_mutex_t  grade_mutex;
    pthread_mutex_t  user_mutex;
    pthread_cond_t   work_cond;
    int              tasks[250]; 
    int              tasks_added;
    int              tasks_taken; 

} tpool_t;

typedef struct user_t{
    char id[10];
    char password[10];
    int is_ta; // 1: TA , 0: student
    int signed_in; // 1:signed in , 0: signed out
    char grade[4]; 
} user_t;

static void handle(struct tpool_t* tm ,int his_socket){
    //handling inputs from the user
    char from_user[250]; 
    int user_idx = -1; //index for users in array users[]
    int logged_in = 0;
    //msgs
    char miss_arg[50] = "Missing argument\n>";
    char not_log[50] = "Not logged in\n>";
    char wrong_info[50] = "Wrong user information\n>";
    char inv_id[50] = "Invalid id\n>";
    char not_allow[50] = "Action not allowed\n>";
    char wrong_inp[50] = "Wrong Input\n>";
    //functions
    char login[50] = "Login";
    char read_gr[50] = "ReadGrade";
    char gr_list[50] = "GradeList";
    char upd_gr[50] = "UpdateGrade";
    char logout[50] = "Logout";
    char exit_2[50]= "Exit";


    while(1){ //reading and handling
        char func[50];
        char arg1[50];
        char arg2[50];
        
        read(his_socket, from_user, 256); // reading inputs from user
        
        int from_user_iter = 0;
        int func_iter = 0;
        int arg1_iter = 0;
        int arg2_iter = 0;

        while(from_user[from_user_iter] <= 122 && from_user[from_user_iter] >= 65){ //readinng the function
            func[func_iter] = from_user[from_user_iter];
            func_iter++;
            from_user_iter++;
        }
        func[func_iter] = '\0';
        
        from_user_iter++;
        while(arg1_iter < 9 && from_user[from_user_iter-1] != '\0'){ //reading ID
            arg1[arg1_iter] = from_user[from_user_iter];
            arg1_iter++;
            from_user_iter++;
        }
        arg1[arg1_iter] = '\0';
        
        from_user_iter++;

        while (from_user[from_user_iter] <= 122 && from_user[from_user_iter] >= 48 && from_user[from_user_iter-2] != '\0'){
            //reading second argument (if exists)
            arg2[arg2_iter] = from_user[from_user_iter];
            arg2_iter++;
            from_user_iter++;
        }           
        arg2[arg2_iter] = '\0';
        
        char wel_message[70] = {'W', 'e', 'l', 'c', 'o', 'm', 'e', ' '}; //welcome msg
        int r = 8; // iterator for wel_message

        if (strcmp(func, login) == 0){ //Login function
            for (int v = 0; v < iter; v++){ // looping over the users
                if (strcmp(arg1, &(users[v]->id)) == 0){ // ID found
                    if (strcmp(arg2, &(users[v]->password)) == 0){ // password matched
                        logged_in = 1;
                        user_idx = v;
                        if (users[v]->is_ta){ // welcome msg for TA
                            wel_message[8] = 'T';
                            wel_message[9] = 'A';
                            wel_message[10] = ' ';
                            r = 11;
                            int j = 0;
                            while (arg1[j] != '\0'){
                                wel_message[r] = arg1[j];
                                j++;
                                r++;
                            }
                            wel_message[r] = '\n';
                            r++;
                            wel_message[r] = '>';
                            r++;
                            wel_message[r] ='\0';
                        }
                        if (!users[v]->is_ta){ //welocme msg for a student
                            char* studentn = "Student";
                            int u = 0;
                            while (studentn[u]!='\0'){
                                wel_message[r] = studentn[u];
                                u++;
                                r++;
                            }
                            wel_message[r] = ' ';
                            r++;
                            int s = 0;
                            while (arg1[s] != '\0'){
                                wel_message[r] = arg1[s];
                                s++;
                                r++;
                            }
                            wel_message[r] = '\n';
                            r++;
                            wel_message[r] = '>';
                            r++;
                            wel_message[r] ='\0';
                        }
                         (write(his_socket, wel_message, strlen(wel_message)+1));
                    break;
                    }
                }
            }
            if (user_idx == -1){ // user not found or wrong password
                write(his_socket, wrong_info, strlen(wrong_info)+1);
            }

        }
        else if (0 == strcmp(func, read_gr)){ // ReadGrade function
            if (!logged_in){ 
                write(his_socket, not_log, strlen(not_log)+1);
            }
            else{
                if (users[user_idx]->is_ta){ // TA reading a grade
                    if (strlen(arg1) == 0){ //TA reading a grade without ID
                        write(his_socket, miss_arg, strlen(miss_arg)+1);
                    }
                    else { // TA reading a grade for a specific ID
                        int std_found = 0;
                        for (int l = 0; l<iter; l++){ // TA printing grade for existing user
                            pthread_mutex_lock(&(tm->grade_mutex));
                            if (strcmp(arg1, &(users[l]->id))==0){
                                std_found =1;
                                char grade_print[6];
                                strcpy(grade_print, &users[l]->grade);
                                strcpy(grade_print + strlen(&users[l]->grade), "\n>\0");
                                write(his_socket, grade_print, strlen(grade_print));
                            }
                            pthread_mutex_unlock(&(tm->grade_mutex));
                        }
                        if (!std_found){ // TA printing grade for nonexisting user
                            write(his_socket, inv_id, strlen(inv_id)+1);
                        }
                    }
                }
                else { // student priting his/her grade
                    if (strlen(arg1) != 0){ // student printing grade for another ID
                        write(his_socket, not_allow, strlen(not_allow)+1);
                    }
                    else{ //student printing his grade
                        pthread_mutex_lock(&(tm->grade_mutex));
                        char grade_print[6];
                        strcpy(grade_print, &users[user_idx]->grade);
                        strcpy(grade_print + strlen(&users[user_idx]->grade), "\n>\0");
                        write(his_socket, grade_print, strlen(grade_print));
                        pthread_mutex_unlock(&(tm->grade_mutex));
                    }
                }
            }
            
        }
        else if (0 == strcmp(func,gr_list)){ //GradeList Function
            if (!logged_in){
                 (write(his_socket, not_log, strlen(not_log)+1));
            }
            else{ //user is logged in
                if (users[user_idx]->is_ta){ // TA requestin Gradelist
                    char grades[257];
                    char *gr_idx = grades;
                    int ctr = 0;
                    for (int h = 0; h<iter; h++){ // looping over students in the user[] array
                        if (!users[h]->is_ta){
                            pthread_mutex_lock(&(tm->grade_mutex));
                            strcpy(gr_idx, &(users[h]->id));
                            gr_idx += strlen(&(users[h]->id));
                            ctr += strlen(&(users[h]->id));
                            gr_idx++;
                            ctr++;
                            *gr_idx = ':';
                            gr_idx++;
                            ctr++;
                            *gr_idx = ' ';
                            gr_idx++;
                            ctr++;
                            strcpy(gr_idx, &(users[h]->grade));
                            gr_idx += strlen(&(users[h]->grade));
                            ctr+= strlen(&(users[h]->grade));
                            *gr_idx = '\n';
                            gr_idx++;
                            ctr++;
                            pthread_mutex_unlock(&(tm->grade_mutex));
                        }
                    }
                    *gr_idx = '>';
                    gr_idx++;
                    ctr++;
                    *gr_idx = '\0';
                    write(his_socket, grades, ctr);
                }
                else{ //student
                    write(his_socket, not_allow, strlen(not_allow)+1);
                }
            }

        }
        else if (strcmp(func, upd_gr) == 0){ //Update Grade function - only for TA
            if (!logged_in){
                write(his_socket, not_log, strlen(not_log)+1);
            }
            else if (!users[user_idx]->is_ta){ // students not allowed
                write(his_socket, not_allow, strlen(not_allow)+1);
            }
            else{ //TA
                if ((strlen(arg1)==0) || (strlen(arg2)==0)){
                    write(his_socket, miss_arg, strlen(miss_arg)+1);
                }
                else{
                    int d = 0;
                    int up_done = 0;
                    pthread_mutex_lock(&(tm->grade_mutex));
                    for (d; d<iter; d++){
                        if (strcmp(&(users[d]->id), arg1)==0){
                            strcpy(&(users[d]->grade), arg2);
                            up_done = 1;

                            break;
                        }
                    }
                    pthread_mutex_lock(&(tm->user_mutex)); // to initiate another special mutex for user update
                    if (!up_done){
                        struct user_t *new_user = malloc(sizeof(struct user_t));
                        strcpy(&(new_user->id), arg1);
                        strcpy(&(new_user->grade), arg2);
                        users[iter] = new_user;
                        iter++;
                    }
                    pthread_mutex_unlock(&(tm->user_mutex));
                    pthread_mutex_unlock(&(tm->grade_mutex));
                    write(his_socket, "\n>", 2);
                }
            }
        }
        else if (strcmp(func, logout) == 0){ //Logout function 
            char bye_msg[70] = {'G', 'o', 'o', 'd', ' ', 'b', 'y', 'e', ' '};
            int b = 8; // iterator for bye msg
            if (!logged_in){
                write(his_socket, not_log, strlen(not_log)+1);
            }
            else { //signing out
                strcpy(bye_msg+9, &users[user_idx]->id);
                strcpy(bye_msg+strlen(bye_msg), "\n>");
                logged_in = 0;
                user_idx = -1;
                write(his_socket, bye_msg, strlen(bye_msg)+1);
            }
        }
        else if (strcmp(func, exit_2) == 0){  //Exit function
            char ex[10] ="exit"; //send exit to client to invoke a kill signal
            write(his_socket, ex, strlen(ex)+1);
            close(his_socket);
            return;

        }
        else { //in case of a wrong input
            write(his_socket, wrong_inp, strlen(wrong_inp)+1);
        }
    }
}

static void *tpool_worker(void *arg){
    tpool_t* tm = arg;

    while(1){
        pthread_mutex_lock(&(tm->work_mutex));
        while (tm->tasks_added - tm->tasks_taken <= 0){
            pthread_cond_wait(&(tm->work_cond), &(tm->work_mutex));
        }

        int his_socket = tm->tasks[tm->tasks_taken];
        if (his_socket != -1){
            tm->tasks[tm->tasks_taken] = -1;
            tm->tasks_taken++;
            pthread_mutex_unlock(&(tm->work_mutex));
            handle(tm ,his_socket);
        }
        else {
            pthread_mutex_unlock(&(tm->work_mutex));
        }  
    }
}

int main(int argc, char** argv) {

    // reading the students.txt
    FILE *f = fopen("students.txt", "r");
    while(!feof(f)){
        struct user_t* user = malloc(sizeof(struct user_t));
        char c = fgetc(f);
        int id_i = 0;
        while (c != ':'){ //reading IDs
            user->id[id_i] = c;
            c = fgetc(f);
            id_i++;
        }
        user->id[id_i] = '\0';
        c = fgetc(f);
        int password_i = 0;
        while (c != '\n' && !feof(f)){ //reading password
            user->password[password_i] = c;
            c = fgetc(f);
            int d = feof(f);
            password_i++;
        }
        strcpy(&user->grade, "0");
        user->signed_in = 0;
        user->is_ta = 0;
        users[iter] = user;
        iter++;
    }

    // readig assistants.txt
    FILE *TA = fopen("assistants.txt", "r");
    while(!feof(TA)){
        struct user_t *user_ta = malloc(sizeof(struct user_t));
        //struct user_t n_user_ta = 
        //user_ta = &n_user_ta;
        char c = fgetc(TA);
        int id_i = 0;
        while (c != ':'){ // reading IDs
            user_ta->id[id_i] = c;
            c = fgetc(TA);
            id_i++;
        }
        user_ta->id[id_i] = '\0';
        c = fgetc(TA);
        int password_i = 0; // reading password
        while (c != '\n' && !feof(TA)){
            user_ta->password[password_i] = c;
            c = fgetc(TA);
            password_i++;
        }
        user_ta->password[password_i] = '\0';
        strcpy(&user_ta->grade, "0");
        user_ta->signed_in = 0;
        user_ta->is_ta = 1;
        users[iter] = user_ta;
        iter++;
    }

    // initate thread pool
    struct tpool_t* t_pool = malloc(sizeof(struct tpool_t));
    pthread_mutex_init(&(t_pool->work_mutex), NULL);
    pthread_mutex_init(&(t_pool->grade_mutex), NULL);
    pthread_mutex_init(&(t_pool->user_mutex), NULL);
    pthread_cond_init(&(t_pool->work_cond), NULL);
    t_pool->tasks_added = 0;
    t_pool->tasks_taken = 0;

    int port = atoi(argv[1]); 
    pthread_t threads[5];

    for (size_t i=0; i<5; i++) {
        pthread_create(&threads[i], NULL, tpool_worker, t_pool);
    }
    

    
    int clifd, srvfd = tcp_establish(port);
    while (1){  
        DO_SYS( clifd = accept(srvfd, NULL, NULL) );
        pthread_mutex_lock(&(t_pool->work_mutex));
        t_pool->tasks[t_pool->tasks_added] = clifd;
        t_pool->tasks_added++;
        pthread_cond_signal(&(t_pool->work_cond));
        pthread_mutex_unlock(&(t_pool->work_mutex));
    }   
}

