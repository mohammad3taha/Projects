#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <memory.h>
#include <unistd.h>
#include <pthread.h>
#include <signal.h>


// global variable
int fds[2];
pthread_mutex_t pipe_mutex;

#define DO_SYS(syscall) do {		\
    if( (syscall) == -1 ) {		\
        perror( #syscall );		\
        exit(EXIT_FAILURE);		\
    }						\
} while( 0 )

struct addrinfo*
alloc_tcp_addr(const char *host, uint16_t port, int flags)
{
    int err;   struct addrinfo hint, *a;   char ps[16];

    snprintf(ps, sizeof(ps), "%hu", port); 
    memset(&hint, 0, sizeof(hint));
    hint.ai_flags    = flags;
    hint.ai_family   = AF_UNSPEC;
    hint.ai_socktype = SOCK_STREAM;
    hint.ai_protocol = IPPROTO_TCP;

    if( (err = getaddrinfo(host, ps, &hint, &a)) != 0 ) {
        fprintf(stderr,"%s\n", gai_strerror(err));
        exit(EXIT_FAILURE);
    }

    return a; // should later be freed with freeaddrinfo()
}

int tcp_connect(const char *host, uint16_t port)
{
    int clifd;
    struct addrinfo *a = alloc_tcp_addr(host, port, 0);

    DO_SYS( clifd = socket( a->ai_family,
				 a->ai_socktype,
				 a->ai_protocol ) 	);
    DO_SYS( connect( clifd,
				 a->ai_addr,
				 a->ai_addrlen  )   );

    freeaddrinfo( a );
    return clifd;
}

void communication_process(const char *host, uint16_t port) 
{
  char buf[256], to_send[256];
  int k, fd = tcp_connect(host, port);

  int done = 1;
    while (done) {
        bzero(to_send, 256);
        read(fds[0], to_send, 256);
        DO_SYS(     write(fd, to_send, strlen(to_send)+1)  );
        DO_SYS( k = read (fd, buf, sizeof(buf))  );
        if (0 == strcmp(buf, "exit")){
            pid_t p_pid = getppid();
            kill(p_pid, SIGKILL);
            exit(1);
        }
        DO_SYS(     write(STDOUT_FILENO, buf, k) );
        
    }
    DO_SYS(     close(fd)                    );
}

void command_line_interpreter(){
    char from_user[256];
    char line[256];
    printf(">");
    while(1){
        bzero(from_user, 256);
        if(fgets(line, sizeof(line), stdin)) { // read from user
            if (1 == sscanf(line, "%[^\n]%*c", from_user)) { //[^\n] isn't newline chars
                write(fds[1], from_user, strlen(from_user) + 1);
            }
        }
    }
}


int main(int argc, char** argv) {
    char *server_name = argv[1];
    int port = atoi(argv[2]);

    pthread_mutex_init(&pipe_mutex, NULL);
    pipe(fds);
    if (fork() == 0){
        close(fds[1]);
        communication_process(server_name, port);
    }
    else{
        close(fds[0]);
        command_line_interpreter();
    }
    return 0;
}