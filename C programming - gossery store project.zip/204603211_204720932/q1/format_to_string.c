#include <stdio.h>
#include <string.h>
#include <math.h>
#define MAX_SIZE (256)

/*
1. Mention two format strings that your code is not handling correctly. 
    a. A string with a length greater than 255.
    b. In comparison to the original sprintf, our function does not deal correctly with placeholders like 
        "%e, %E, %n, %p, %g, ,%G, %o, %u, %X".

2. What is the behavior of the function for these format strings.
    a. The function continues to work regularly, despite the restriction of MAX SIZE. The maximum size 
        limitation does not prevent the function to continue coppying into a memory that doesn't belong 
        to us, causing "stack smashing" as warned by the system. In comparison, the original (built in) 
        sprintf function prevents such a behavior, and sends a message ("illegal hardware instruction") 
        to the user without copying into the buffer at all.
    b. The function simply copies the chars as they appear in the string, i.e. it doesn't replace it 
        with any of the arguments. 
*/

int int_to_str(unsigned int x, char* res, int base) 
{ 
    int i = 0; 
    while (x) { // it stops once we get 0 or if x is 0 it doesn't enter at all 
        int rem = x % base;
        // we use the 2nd condition for the 10th base, where the remainder is always less/equal to 9
        res[i++] = (rem > 9) ? (rem - 10) + 'a' : rem + '0'; 
        x = x / base;  
    }

    // reverse string
    int ii = 0, jj = i - 1;
    char temp;
    while (ii < jj) { 
        temp = res[ii]; 
        res[ii] = res[jj]; 
        res[jj] = temp; 
        ii++; 
        jj--; 
    } 
    return i; //returns the position in the buffer
} 

int float_to_str(float n, char* res, int after_point) 
{ 
    int int_part = (int)n; // integer part 
    float fl_part = n - (float)int_part; // float part 
    int i = int_to_str(int_part, res, 10); // integer part to string
  
    if (0 != after_point) { // handle precision level
        if (0 != fl_part) { // check for after point digits.
            res[i] = '.'; 
        }
        // handling trailing zeros
        fl_part = fl_part * pow(10, after_point); 
        int fl_part_int = (int)fl_part; 
        int counter = 0;
        while (0 == fl_part_int % 10 && fl_part_int > 0) { //counting zeros
            fl_part_int /= 10; 
            counter++;
        }
        after_point -= counter; // removing trailing zeros - if found
        if (0 == fl_part_int) {
            return i; // returning last position in buffer
        }
        int_to_str((int)fl_part_int, res + i + 1, 10); // writing in buffer the float part
    } 
    return i + after_point + 1; // returning last position in buffer
} 

int format_to_string(char buffer[MAX_SIZE], const char *format, void *arg1, void *arg2, void *arg3)
{
    char ch; 
    char *pchar; 
    int i = 0; // index of buffer
    int p = 0; // index of pointer array 
    int *d; // pointer for integer
    unsigned int *w; // pointer for positive integer
    int pos; // position in buffer after calling a helper function
    int ph_counter = 0; // counter of place holders
    float *f; //pointer for float
    void *arg_pointers[] = {arg1, arg2, arg3}; // array of the arguments
    char the_chars[] = "csdfx";
    char chrs[] = "csdfx%";

    while ((ch = *format++)) { /*   assinging char to variable ch in the while condition, 
                                    hence the double parentheses. The while loop stops when it 
                                    reaches "/0" in the format string.*/
        if ('%' == ch && NULL != strchr(chrs, *format)) {
            if (NULL != strchr(the_chars, *format)) {
                ph_counter += 1;
            }          
            if (3 < ph_counter) {
                return -1;
            } 
            switch (ch = *format++) { 
                case '%':
                    buffer[i++] = '%';
                    break;
                case 'c':
                    pchar = (char*)arg_pointers[p++];
                    buffer[i++] = *pchar;
                    break;
                case 's':
                    pchar = (char*)arg_pointers[p++];
                    strcpy(&buffer[i], pchar);
                    i += strlen(pchar);
                    break;
                case 'd':
                    d = (int*)arg_pointers[p++];
                    if (*d < 0) {
                        *d *= -1; 
                        buffer[i++] = '-';
                    }
                    pos = int_to_str(*d, &buffer[i], 10); // calling int_to_str with base 10
                    i += pos;
                    break;
                case 'f':
                    f = (float*)arg_pointers[p++];
                    if (*f < 0) {
                        *f *= -1; 
                        buffer[i++] = '-';
                    }
                    if (*f < 1) { 
                        buffer[i++] = '0';
                    }
                    pos = float_to_str(*f, &buffer[i], 7); // calling float_to_str with precision of 7
                    i += pos;
                    break;
                case 'x':
                    w = (unsigned int*)arg_pointers[p++];
                    pos = int_to_str(*w, &buffer[i], 16); // calling int_to_str with base 16
                    i += pos;
                    break;
            }
        } else {
            buffer[i] = ch;
            i++;
        }
    }
    return strlen(buffer);
}
