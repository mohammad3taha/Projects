#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>
#define  MAX_PRODUCTS 25

/*1. What changes in the function are to be made to prevent statically allocating MAX_PRODUCTS 
    and make it dynamically?
    Initially, we dynamically allocate memory for the array of the products' pointers 
    (in the struct of store_t). The initial size of the memory allocated should be at 
    least the size of pointer*the initial number of products (While it's greater than zero).
    In the function "add_product" if the new product's barcode doesn't match any of the existing 
    barcodes, (so, the function realize that it should add the new product to the store), 
    the function should reallocate memory to the array and it's size should be updated according 
    to the new number of products.
*/

typedef struct {
    int year;
    int month;
    int day;
} date_t;

typedef struct {
    char *name;
    char *category;
    char *barcode;
    int amount;
    double price;
    date_t *expire_date;
} product_t;

typedef struct {
    product_t *products[MAX_PRODUCTS];
    int number_of_products;
} store_t;

product_t *create_product(const char *name, const char *category, const char *barcode, int amount, double price, date_t *expire_date)
{
    if (0 != strlen(name) && 0 != strlen(category) && 0 != strlen(barcode) && amount > 0 && NULL != expire_date) {
        // allocating memory
        product_t *product = malloc(sizeof(*product));
        product->name = malloc(strlen(name) + 1);
        product->category = malloc(strlen(category) + 1);
        product->barcode = malloc(strlen(barcode) + 1);
        date_t *date = malloc(sizeof (date_t));
        
        // check if memory allocation failed
        if (NULL == product || NULL == product->name || NULL == product->category || NULL == date) { 
            free(product->name);
            free(product->category);
            free(product->barcode);
            free(date);
            return NULL;
        }
        
        //copying values to the struct
        strcpy(product->name, name);
        strcpy(product->category, category);
        strcpy(product->barcode, barcode);
        product->amount = amount;
        product->price = price;

        //date assignments
        date->day = expire_date->day;
        date->month = expire_date->month;
        date->year =  expire_date->year;
        product->expire_date = date;

        return product;
    }
    return NULL;   
}


int add_product(store_t *store, product_t *product)
{
    if (NULL == store || NULL == product) {
        return -1;
    }
    bool exists = false;

    for (int i = 0; i < store->number_of_products; i++) {
        if (!strcmp(store->products[i]->barcode, product->barcode)) {
            exists = true;
            store->products[i]->amount += product->amount;
            free(product->expire_date);
            free(product->name);
            free(product->barcode);
            free(product->category);
            free(product);
        }
    }
    if (false == exists) {
        store->products[store->number_of_products] = product;
        store->number_of_products += 1;
    }
    return 0;
}

int remove_product(store_t *store, const char *barcode)
{
    if (NULL == store || 0 == strlen(barcode)) {
        return -1;
    } 
    for (int i = 0; i < store->number_of_products; i++) {
        if (strcmp(store->products[i]->barcode, barcode) == 0) {
            free(store->products[i]->name);
            free(store->products[i]->barcode);
            free(store->products[i]->category);
            free(store->products[i]->expire_date);
            free(store->products[i]);
            store->products[i] = store->products[store->number_of_products - 1];
            store->products[store->number_of_products - 1] = 0;
            store->number_of_products--;
            return 0;
        }
    }
    return -1;
}

void print_product(product_t *product)
{
    printf("Product %s [%s]\n", product->name, product->barcode);
    printf("Category: %s\n", product->category);
    printf("Price: %lf\n", product->price);
    printf("Amount: %d\n", product->amount);
    printf("Expires: %d/%d/%d\n", product->expire_date->day, product->expire_date->month, product->expire_date->year);
}

void print_products(store_t *store)
{
    if (NULL != store) {
        for (int i = 0; i < store->number_of_products; i++) {
            print_product(store->products[i]);
        }
    }
}

void print_expired_products(store_t *store, date_t *now)
{
    if (NULL == store || NULL == now) {
        return;
    }

    for (int i = 0; i < store->number_of_products; i++) {
        //check dates
        if (store->products[i]->expire_date->year < now->year) {
            print_product(store->products[i]);
        } else {
            if (store->products[i]->expire_date->month < now->month && store->products[i]->expire_date->year == now->year) {
                print_product(store->products[i]);
            } else {
                if (store->products[i]->expire_date->day < now->day && store->products[i]->expire_date->month == now->month) {
                    print_product(store->products[i]);
                }
            }
        }
    }
    return;
}

void print_category(store_t *store, const char *category)
{
    if (NULL == store) {
        return;
    }
    if (NULL == category) {
        print_products(store);
        return;
    }

    for (int i = 0; i < store->number_of_products; i++) {
        if (0 == strcmp(store->products[i]->category, category)) {
            print_product(store->products[i]);
        }
    }
}
